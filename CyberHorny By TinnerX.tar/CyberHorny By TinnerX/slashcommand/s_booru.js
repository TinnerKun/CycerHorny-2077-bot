const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js')
const Booru = require('booru');
const cooldown = new Set()

module.exports = {
	names: 'booru',
	data: new SlashCommandBuilder()
	.setName('booru')
	.setDescription('Group Booru and Random Tag')
    .addStringOption(option =>
		option.setName('group')
			.setDescription('เว็บที่ต้องการ')
			.setRequired(true)
			.addChoice('https://rule34.xxx', 'rule34.xxx')
            .addChoice('https://gelbooru.com', 'gelbooru.com')
            .addChoice('https://yande.re', 'yande.re')
            .addChoice('https://safebooru.org', 'safebooru.org')
            .addChoice('https://xbooru.com', 'xbooru.com')
            .addChoice('https://rule34.paheal.net', 'rule34.paheal.net')
            .addChoice('https://hypnohub.net', 'hypnohub.net')
            )
    
	.addStringOption(option => option.setName('name').setDescription('Title , Name , Tag')),
	async execute(client , interaction) {
        const url = interaction.options.getString('group');
        const tag = interaction.options.getString('name');

        let loading = new MessageEmbed()
				.setColor('RANDOM')
				.setTitle("Loading...")
				.setImage('https://cdn.discordapp.com/attachments/889652344202088458/935468552750792744/00_00_00-00_00_30.gif')
				.setDescription('โปรดรอหน่อย น่าา ระบบกำลังหาให้')
				.setTimestamp()
				.setFooter('Develop By TinnerX');
			await interaction.reply({ embeds: [loading] });


            if (cooldown.has(interaction.guildId)) {
				await interaction.reply({ embeds: [new MessageEmbed().setAuthor('โปรดลองอีกครั้งใน 5 วินาที').setColor('RANDOM')] }).then(msg => {
					setTimeout(() => interaction.deleteReply(), 3000);
				});
				return
			} else {
				cooldown.add(interaction.guildId);
				setTimeout(() => {
					cooldown.delete(interaction.guildId);
				}, 5000);
			}

        if(tag !== null) {
            use(tag)
        } else {
            use('touhou')
        }

        async function use(taga) {
            Booru.search(url, taga, { limit: 1, random: true })
            .then(async posts => {
            for (let post of posts)
      
            var imgs = new MessageEmbed()
                    .setColor('RANDOM')
                    .setTitle('Image ' + taga)
                    .setDescription('ลิงค์รูป : '+ post.fileUrl)
                    .setImage(post.fileUrl)
                    .setTimestamp()
                    .setFooter('Code By : TinnerX');
                    await interaction.editReply({embeds: [imgs]});
            })
        }    
	},
};