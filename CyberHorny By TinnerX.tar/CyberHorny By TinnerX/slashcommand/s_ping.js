const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js')

module.exports = {
	names: 'ping',
	data: new SlashCommandBuilder()
	.setName('ping')
	.setDescription('ดูคำสังทั้งหมด'),
	async execute(client , interaction) {
        let embed = new MessageEmbed()
            .setColor('RANDOM')
            .setTitle(`ปิงของบอทตอนนี้อยู่ที่ ${client.ws.ping}ms !`)
        await interaction.reply({ embeds: [embed] });
	},
};
