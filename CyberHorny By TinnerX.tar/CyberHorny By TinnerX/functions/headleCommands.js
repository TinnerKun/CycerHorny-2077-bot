const fs = require('fs');

module.exports = (client) => {
    client.handleCommands = async (commandFolders, path) => {
        client.commandArray = [];
        for(folder of commandFolders) {

            const commandFiles = fs.readdirSync(`${path}`).filter(file => file.endsWith('.js'));

            for (const file of commandFiles) {
                const command = require(`../slashcommand/${file}`);
                client.commands.set(command.data.name, command);
                client.commandArray.push(command.data.toJSON()); 
            }
        }

    }
};