const { Embed } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed, MessageSelectMenu } = require('discord.js')

module.exports = async (client, interaction) => {
        if (interaction.isCommand()) {
            const command = client.slashcommand.get(interaction.commandName);
        if (!command) return;
        try {
            await command.execute(client,interaction)
            commands_log(client,interaction)
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: 'There was an error while executing this command!',
                ephemeral: false
            });
        }

        function commands_log(client, message) {
            let time = new Date();
            console.log(`Slash use! | ${message.commandName} | ${message.member.guild.name} | ${message.user.username}#${message.user.discriminator} | ${time}`)
        }
        } else if (interaction.isSelectMenu()) {

        }
}