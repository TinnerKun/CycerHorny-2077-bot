const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
module.exports = async (client) => {
    console.log(`I'm ready! Nhentai of shard ${client.shard.ids}`)
    const rest = new REST({
        version: '9'
    }).setToken(client.token);
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(
            Routes.applicationCommands(client.user.id), {
                body: client.slashcommandrest
            },
            
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
}