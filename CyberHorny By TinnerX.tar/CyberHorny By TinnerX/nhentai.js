/*
require('events').EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', function (err) { });
process.on('unhandledRejection', function (err) { });
*/
const config = require("./data.json");
const Discord = require("discord.js");
const { Intents } = require('discord.js');
const { glob } = require('glob')

const client = new Discord.Client({
    intents: [
        "GUILDS",
        "GUILD_BANS",
        "GUILD_EMOJIS_AND_STICKERS",
        "GUILD_INTEGRATIONS",
        "GUILD_INVITES",
        "GUILD_MEMBERS",
        "GUILD_MESSAGES",
        "GUILD_MESSAGE_TYPING",
        "GUILD_WEBHOOKS",
        "DIRECT_MESSAGES",
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.DIRECT_MESSAGES,
        Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,
        Intents.FLAGS.DIRECT_MESSAGE_TYPING,
        Intents.FLAGS.GUILD_BANS,
        Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,
        Intents.FLAGS.GUILD_INTEGRATIONS,
        Intents.FLAGS.GUILD_INVITES,
        Intents.FLAGS.GUILD_MEMBERS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
        Intents.FLAGS.GUILD_MESSAGE_TYPING,
        Intents.FLAGS.GUILD_PRESENCES,
        Intents.FLAGS.GUILD_VOICE_STATES,
        Intents.FLAGS.GUILD_WEBHOOKS
    ]
});
client.commands = new Discord.Collection()

client.on('ready', async () => {

client.user.setActivity(`${config.prefix}help`, { type: 'PLAYING',status: "dnd" });

})

client.it = require("./invite_tracking");
client.it(client);

const eventsFiles = glob.sync("./events/*.js")
const commandFiles = glob.sync("./commands/*.js")
const commandFilesAdmin = glob.sync("./commands/admin/*.js")
const slashcommand = glob.sync("./slashcommand/*.js")
console.log("===========================================================")

for (let i = 0; i < eventsFiles.length; i++) {
    const event = require(eventsFiles[i])
    const eventName = /\/events.(.*).js/.exec("." + eventsFiles[i])[1]
    console.log(`event ${eventName} is ready.`)
    client.on(eventName, event.bind(null, client))
}

console.log("===========================================================")
for (let i = 0; i < commandFiles.length; i++) {
    const command = require(commandFiles[i])
    client.commands.set(command.name, command)
    console.log(`command ${command.name} \t\tis ready.`)
}
console.log("===========================================================")
for (let i = 0; i < commandFilesAdmin.length; i++) {
    const command = require(commandFilesAdmin[i])
    client.commands.set(command.name, command)
    console.log(`command Admin ${command.name}`)
}
console.log("===========================================================")

client.slashcommand = new Discord.Collection()
client.slashcommandrest = []
for (let i = 0; i < slashcommand.length; i++) {
    const commands = require(slashcommand[i])
    client.slashcommand.set(commands.names, commands)
    client.slashcommandrest.push(commands.data)
    console.log(`command slash ${commands.names}`)
}

console.log("===========================================================")

client.login(config.key);