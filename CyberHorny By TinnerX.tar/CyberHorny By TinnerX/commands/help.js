const randomHexColor = require('random-hex-color')
const config = require("../data.json");
const { MessageEmbed } = require('discord.js');
const cooldown = new Set();

module.exports = {
    name: "help",
    async run(client, message) {
        try {
          message.channel.send('ทำเอง ขก.')
        } catch (err) {
            console.log(err)
        }
    }
}