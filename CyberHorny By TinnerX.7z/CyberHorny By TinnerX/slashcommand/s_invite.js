const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js')

module.exports = {
	names: 'invite',
	data: new SlashCommandBuilder()
	.setName('invite')
	.setDescription('ใช้คำสังเชิญบอท'),
	async execute(client , interaction) {
        let embed = new MessageEmbed()
            .setColor('RANDOM')
            .setTitle(`👉 กดตรงนี้เพื่อเชิญบอทสุดน่าลัก`)
			.setDescription('ขอบคุณที่เชิญเค้านะะะะ')
			.setURL('https://discord.com/oauth2/authorize?client_id=823707407368585233&permissions=8&scope=bot%20applications.commands')
			.setImage('https://cdn.discordapp.com/attachments/889652344202088458/935468552750792744/00_00_00-00_00_30.gif')
        await interaction.reply({ embeds: [embed] });
	},
};
