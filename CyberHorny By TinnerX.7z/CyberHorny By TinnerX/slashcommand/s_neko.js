const { SlashCommandBuilder } = require('@discordjs/builders');
const cooldown = new Set()

module.exports = {
	names: 'neko',
	data: new SlashCommandBuilder()
	.setName('neko')
	.setDescription('https://nekos.life/')
	.addStringOption(option =>
		option.setName('image')
			.setDescription('หมวดที่ต้องการหา')
			.setRequired(true)
			.addChoice('feet', 'feet')
			.addChoice('lewdkemo', 'lewdkemo')
			.addChoice('cum', 'cum')
			.addChoice('les', 'les')
			.addChoice('hololewd', 'hololewd')
			.addChoice('feed', 'feed')
			.addChoice('fox_girl', 'fox_girl')
			.addChoice('nsfw_neko_gif', 'nsfw_neko_gif')
			.addChoice('eroyuri', 'eroyuri')
			.addChoice('holoero', 'holoero')
			.addChoice('pussy', 'pussy')
			.addChoice('lizard', 'lizard')
			.addChoice('yuri', 'yuri')
			.addChoice('neko', 'neko')
			.addChoice('feetg', 'feetg')
			.addChoice('hug', 'hug')
			.addChoice('nsfw_avatar', 'nsfw_avatar')
			.addChoice('erofeet', 'erofeet')
			.addChoice('meow', 'meow')
			.addChoice('kiss', 'kiss')
			.addChoice('blowjob', 'blowjob')
			.addChoice('spank', 'spank')
			.addChoice('waifu', 'waifu')
			.addChoice('trap', 'trap')
			.addChoice('lewd', 'lewd')
			),
	
	async execute(client , interaction) {
		const image = interaction.options.getString('image');
		
		if (cooldown.has(interaction.guildId)) {
			await interaction.reply({ embeds: [new MessageEmbed().setAuthor('โปรดลองอีกครั้งใน 5 วินาที').setColor('RANDOM')] }).then(msg => {
				setTimeout(() => interaction.deleteReply(), 3000);
			});
			return
		} else {
			cooldown.add(interaction.guildId);
			setTimeout(() => {
				cooldown.delete(interaction.guildId);
			}, 5000);
		}

		require('axios')('https://nekos.life/api/v2/img/'+image)
		.then(async function (res) {
			await interaction.reply(res.data["url"]);
		})
		.catch(async function (error) {
			console.log(error)
		})		
	},
};
