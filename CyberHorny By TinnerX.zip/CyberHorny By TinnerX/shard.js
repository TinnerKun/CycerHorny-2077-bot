const { ShardingManager } = require("discord.js");
const config = require("./data.json")

const Manager = new ShardingManager("./nhentai.js", {
    token: config.key,
    totalShards: 1,
    respawn: true
})

Manager.on('shardCreate', (shard) => {
    console.log(`Launched shard ${shard.id}`)
})

Manager.spawn({
    amount: 1,
    delay: -1,
    timeout: -1
})