const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js')

module.exports = {
	names: 'help',
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('ดูคำสังทั้งหมด'),
	async execute(client, interaction) {
		await interaction.reply('ทำเอาเอง ขก.')
	},
};