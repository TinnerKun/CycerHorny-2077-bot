const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js')

module.exports = {
	names: 'credit',
	data: new SlashCommandBuilder()
		.setName('credit')
		.setDescription('คนทำและผู้ใช้งาน'),
	async execute(client, interaction) {
        let c = new MessageEmbed()
                .setTitle(`ผู้จัดทำ`)
				.setDescription(`
                Script original : NEXT#8233 and ⵝⵉⵏⵏⴻⵔⴿⵓⵏ#5580
                Bringer to work : *name*
                `)
				.setColor('RANDOM')
				.setTimestamp()
		await interaction.reply({embeds : [c]})
	},
};