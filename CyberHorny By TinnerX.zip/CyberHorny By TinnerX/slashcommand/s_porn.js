const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js')
const { RandomPHUB } = require('discord-phub');
const nsfw = new RandomPHUB(unique = true);
const cooldown = new Set()

module.exports = {
	names: 'porn',
	data: new SlashCommandBuilder()
		.setName('porn')
		.setDescription('Random หาของดีย์'),
	async execute(client, interaction) {
		let check = client.channels.cache.get(interaction.channelId);
		if (check.nsfw === true) {
			let loading = new MessageEmbed()
				.setColor('RANDOM')
				.setTitle("Loading...")
				.setImage('https://cdn.discordapp.com/attachments/889652344202088458/935468552750792744/00_00_00-00_00_30.gif')
				.setDescription('โปรดรอหน่อย น่าา ระบบกำลังหาให้')
				.setTimestamp()
				.setFooter('Develop By TinnerX');
			await interaction.reply({ embeds: [loading] });

			if (cooldown.has(interaction.guildId)) {
				await interaction.reply({ embeds: [new MessageEmbed().setAuthor('โปรดลองอีกครั้งใน 5 วินาที').setColor('RANDOM')] }).then(msg => {
					setTimeout(() => interaction.deleteReply(), 3000);
				});
				return
			} else {
				cooldown.add(interaction.guildId);
				setTimeout(() => {
					cooldown.delete(interaction.guildId);
				}, 5000);
			}
			async function main() {
				function pos() {
					const items = ['gif', 'jpeg', 'png']
					var item = items[Math.floor(Math.random() * items.length)];
					const rnd = nsfw.getRandom(item);
					return rnd;
				}
				let data = pos();
				if (data['url'] === undefined || data['type'] === undefined || data['type'] === 'mp4') {
					main();
				} else {
					let embed = new MessageEmbed()
						.setColor('RANDOM')
						.setURL(data['url'])
						.setImage(data['url'])
					await interaction.editReply({ embeds: [embed] });
				}
			}
			main();
		} else {
			async function post() {
				let sfw = new MessageEmbed()
					.setTitle(`Protection SFW Room`)
					.setDescription('เนื้อหาต่อไปนี้เหมาะสำหรับห้อง NSFW เท่านั้น ขอภัย')
					.setColor("#ff0000")
					.setTimestamp()
				await interaction.reply({ embeds: [sfw] });
			}
			post();
		}
	}
};
