const config = require("../data.json")
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');
const fs = require('fs');
module.exports = async (client, message) => {
    const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${config.prefix})\\s*`);
    if (!prefixRegex.test(message.content)) return;
    const [, matchedPrefix] = message.content.match(prefixRegex);
    if(matchedPrefix !== config.prefix && matchedPrefix !== `<@!${client.user.id}>`) return;
    if (message.author.bot) return
        try {

            const args = message.content.slice(matchedPrefix.length).trim().split(/ +/);
            const command = args.shift().toLowerCase();
            const cmd = client.commands.find(cmd => cmd.aliases?.includes(command)) ? client.commands.find(cmd => cmd.aliases?.includes(command)) : client.commands.get(command)
            
            if (command.length === 0) return message.channel.send({embeds :[new MessageEmbed()
                .setColor("RANDOM")
                .setFooter(client.user.username + " | Version 1.16.5" ,client.user.displayAvatarURL())
                .setTitle(`ห๊ะ ! สวัสดี มีอะไรให้ช่วยไหมครับ ?`)
                .setDescription(`Prefix : ${config.prefix}`)
            ]});

            if (!cmd) return

            let statuss = fs.readFileSync("statuscheck.json");
            let statuscheck = JSON.parse(statuss);
            let sfw = new MessageEmbed()
                .setTitle(statuscheck["title"])
                .setDescription(statuscheck["Description"])
                .setColor("RANDOM")
                .setTimestamp()            
            
            if (statuscheck["status"] === "true" && !config.owner.includes(message.author.id)) return message.channel.send({ embeds: [sfw] }).then(() => commands_log(client, message));
            if (cmd.admin === true && !config.owner.includes(message.author.id)) return message.channel.send({embeds : [new MessageEmbed().setTitle('คุณไม่สามารถใช้คำสั่งของ Admin ได้').setColor("#00ffff").setFooter(client.user.username + " | Version 1.16.5" , client.user.displayAvatarURL())]}).then(() => commands_log(client, message))
            
            
            message.channel.sendTyping().then(async () => await cmd.run(client, message, args).then(() => commands_log(client, message))) // UseTypeing

            function commands_log(client, message) {
                let time = new Date();
                console.log(`Command use! | ${message.content} | ${message.guild.name} | ${message.author.tag} | ${time}`)
            }
        } catch (err) {
            console.log(err)
        }
}